package org.comtel2000.fritzhome.model;

public class Switcher implements FDevice, Switch, Temperature, Powermeter {


}
